#ifndef __SSTRACKINFO_H__
#define __SSTRACKINFO_H__

#include <math.h>

struct ssTrackInfo
{
	enum {
		NAME_MAX = 32,	// �`�����l�����̍ő咷

		OCT4_A = 57,	// �I�N�^�[�u 4 �� A �̃L�[�R�[�h

		PAN_OFF = 0,	// ���E OFF
		PAN_LEFT = 1,	// �ł���
		PAN_CENTER = 4,	// ����
		PAN_RIGHT = 7,	// �ł��E
		PAN_MASK = 8,	// �}�X�N
	};
	BYTE keyon;			// 0xff:ON 0x00:OFF other:���̑�
	BYTE keycode;		// 00= o0c
	BYTE volume;		// 0x00-0x7f
	BYTE pan;			// 0:off 1:left 4:center 7:right
	char name[NAME_MAX];
};

static inline int Hz2Kc(double _freq)
{
	int kco = (int)(12.0 * log(_freq/440.0) / log(2.0) + ssTrackInfo::OCT4_A + 0.5);
	if (kco < 0) {
		kco = 0;
	} else if (kco > 127) {
		kco = 127;
	}
	return kco;
}

static inline void InitTrackInfo(ssTrackInfo *_info)
{
	_info->keycode = ssTrackInfo::OCT4_A;
	_info->keyon = 0x00;
	_info->volume = 0;
	_info->pan = ssTrackInfo::PAN_CENTER;
	_info->name[0] = '\0';
}

#endif // __SSTRACKINFO_H__
